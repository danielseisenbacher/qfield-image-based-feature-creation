# qfield-image-based-feature-creation
QField qml Plugin for creating a feature in a Point Layer based on the EXIF information of an image.
